<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $sql = "SELECT * FROM visits WHERE date='$date' AND time='$time'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "Termin jest już zajęty!";
    } else {
        $sql = "INSERT INTO visits (name, email, phone, date, time) VALUES ('$name', '$email', '$phone', '$date', '$time')";

        if ($conn->query($sql) === TRUE) {
            echo "Wizyta zarezerwowana!";
        } else {
            echo "Błąd: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rezerwacja Wizyty</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="animal-page">
    <div class="container">
        <h2>Rezerwacja Wizyty</h2>
        <form method="post">
            <label for="name">Imię i Nazwisko:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Telefon:</label>
            <input type="tel" id="phone" name="phone" required>

            <label for="date">Data wizyty:</label>
            <input type="date" id="date" name="date" required>

            <label for="time">Godzina wizyty:</label>
            <input type="time" id="time" name="time" required>

            <button type="submit">Zarezerwuj</button>
        </form>
    </div>
</body>
</html>