<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $animal = $_POST['animal'];

    $sql = "INSERT INTO adoptions (name, email, phone, animal) VALUES ('$name', '$email', '$phone', '$animal')";

    if ($conn->query($sql) === TRUE) {
        echo "Formularz adopcyjny wysłany!";
    } else {
        echo "Błąd: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adopcja</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="animal-page">
    <div class="container">
        <h2>Formularz Adopcyjny</h2>
        <form method="post">
            <label for="name">Imię i Nazwisko:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Telefon:</label>
            <input type="tel" id="phone" name="phone" required>

            <label for="animal">Wybierz zwierzę:</label>
            <select id="animal" name="animal" required>
                <option value="pies1">Pies 1</option>
                <option value="pies2">Pies 2</option>
            </select>

            <button type="submit">Wyślij</button>
        </form>
    </div>
</body>
</html>