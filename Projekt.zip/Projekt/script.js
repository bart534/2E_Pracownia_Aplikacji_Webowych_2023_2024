document.addEventListener('DOMContentLoaded', function() {
    // Obsługa galerii zdjęć
    const gallery = document.querySelector('.gallery');
    gallery.addEventListener('click', function(event) {
        if (event.target.tagName === 'IMG') {
            alert('Kliknięto na zdjęcie: ' + event.target.alt);
        }
    });

    // Walidacja formularza rezerwacji wizyty
    const visitForm = document.querySelector('#visit form');
    visitForm.addEventListener('submit', function(event) {
        const date = document.getElementById('date').value;
        const time = document.getElementById('time').value;

        if (!date || !time) {
            alert('Proszę wypełnić wszystkie pola!');
            event.preventDefault();
        }
    });
});