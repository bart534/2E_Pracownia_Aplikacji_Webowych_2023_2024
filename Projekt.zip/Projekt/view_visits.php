<?php
session_start();
include 'db.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

$sql = "SELECT * FROM visits ORDER BY date, time";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Zarezerwowane Wizyty</h2>";
    echo "<table border='1'>";
    echo "<tr><th>Imię i Nazwisko</th><th>Email</th><th>Telefon</th><th>Data</th><th>Godzina</th></tr>";

    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['phone'] . "</td>";
        echo "<td>" . $row['date'] . "</td>";
        echo "<td>" . $row['time'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "Brak zarezerwowanych wizyt.";
}
?>